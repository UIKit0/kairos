/*
 *	HNLiftSender.h
 *  webapp
 *
 *  Created by tahiche on 12/06/11.
 *  Copyright 2011 Hnlab.org. All rights reserved.
 */

#import <Foundation/Foundation.j>


@interface HNLiftSender : CPObject 
{
    
}

@end
